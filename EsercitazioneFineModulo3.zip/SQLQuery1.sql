/* ALTER TABLE Region 

ADD CONSTRAINT FK_CountryID FOREIGN KEY (CountryID) REFERENCES Country(CountryID)
;

ALTER TABLE	Winery

ADD CONSTRAINT FK_CountryID1 FOREIGN KEY (CountryID) REFERENCES Country(CountryID),
    CONSTRAINT FK_RegionID FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
;

ALTER TABLE Wine 

ADD CONSTRAINT FK_CountryID2 FOREIGN KEY (CountryID) REFERENCES Country(CountryID),
    CONSTRAINT FK_RegionID1 FOREIGN KEY (RegionID) REFERENCES Region(RegionID),
    CONSTRAINT FK_WineryID FOREIGN KEY (WineryID) REFERENCES Winery(WineryID)
;

ALTER TABLE Rating 

ADD CONSTRAINT FK_WineID FOREIGN KEY (WineID) REFERENCES Wine(WineID)
;

In questo modo, dopo aver caricato le tabelle direttamente da file Excel, le ho collegate con le PK e FK 

*/

-- QUERIES

/* 1. Lista dei vini con la corrispondente Vineria per regione e Paese */

SELECT 
       Wine.WineName, 
       Winery.Winery, 
	   Region.Region,
	   Country.Country
FROM Wine
JOIN Winery  ON Wine.WineryID = Winery.WineryID
JOIN Region  ON Wine.RegionID = Region.RegionID
JOIN Country ON Country.CountryID = Region.CountryID
;
 
 /* 2. Media del Rating per ogni variet� di vino*/

SELECT 
       Variety, 
       AVG(Rating) AS AverageRating
FROM Wine
GROUP BY Variety
;

/* 3. Media del prezzo per ogni Vineria */

SELECT 
       Winery.Winery, 
	   AVG(Wine.Price) AS AveragePrice
FROM Wine
JOIN Winery ON Wine.WineryID = Winery.WineryID
GROUP BY Winery.Winery
;

/* 4. Le 5 Vinerie con il miglior rating */

SELECT  TOP 5
        Winery.Winery, 
		AVG(Wine.Rating) AS AverageRating
FROM Winery
JOIN Wine ON Wine.WineryID = Winery.WineryID
GROUP BY Winery.Winery
ORDER BY AverageRating DESC 
;

/* 5. Migliori vini con rating superiore a 4 e prezzo maggiore di 200 
P.s. I rating doveno essere col punto ed anche i prezzi, ma non sono stati caricati cos� da sql, perci� ho scritto 
40 che sta per 4.0 e 20000 che sta per 200.00 */

SELECT 
       Wine.WineName, 
	   Wine.Rating, 
	   Wine.Price
FROM Wine
WHERE Wine.Rating > 40 AND Wine.Price > 20000
;

/* 6. Tutti i vini prodotti in una specifica regione e le relative informazioni*/

SELECT * 
FROM  Wine 
WHERE RegionID = (
                   SELECT RegionID 
				   FROM   Region 
				   WHERE  Region = 'Toscana')
;

/* 7. Numero di vini per ogni variet�*/

SELECT Variety, 
       COUNT(*) AS WineCount 
FROM Wine 
GROUP BY Variety
;

/* 8. Numero totali di vini per ogni anno*/

SELECT ProductionYear, 
       COUNT(*) AS TotalWines
FROM Wine
GROUP BY ProductionYear
;

/* 9. Numero massimo e minimo di vini per ogni regione*/

SELECT
      Region,
      MAX(WineCount) AS MaxWines,
      MIN(WineCount) AS MinWines
FROM (
      SELECT
             Region.Region,
             COUNT(*) AS WineCount
      FROM Wine
      JOIN Region ON Wine.RegionID = Region.RegionID
      GROUP BY Region.Region) AS WineCounts
      GROUP BY Region
;

/* 10. Numero totale di Vinerie per ogni Paese*/

SELECT
       Country.Country,
       COUNT(DISTINCT Winery.WineryID) AS TotalWineries
FROM
    Country
LEFT JOIN
    Winery ON Country.CountryID = Winery.CountryID
GROUP BY
    Country.Country
;
